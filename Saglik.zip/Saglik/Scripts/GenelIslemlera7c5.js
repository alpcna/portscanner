﻿(function ($) {
    $.QueryString = (function (a) {
        if (a == "") return {};
        var b = {};
        for (var i = 0; i < a.length; ++i) {
            var p = a[i].split('=');
            if (p.length != 2) continue;
            b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
        return b;
    })(window.location.search.substr(1).split('&'))
})(jQuery);

String.prototype.toTRUppercase = function () {
    var str = [];
    for (var i = 0; i < this.length; i++) {
        var code = this.charCodeAt(i);
        var c = this.charAt(i);

        if (code == 305) //ı
            str.push(String.fromCharCode(73));
        else if (code == 105)  // i
            str.push(String.fromCharCode(304));
        else if (code == 287)  // ğ
            str.push(String.fromCharCode(286));
        else if (code == 252)  // ü
            str.push(String.fromCharCode(220));
        else if (code == 351)  // ş
            str.push(String.fromCharCode(350));
        else if (code == 246)  // ö
            str.push(String.fromCharCode(214));
        else if (code == 231)  // ç
            str.push(String.fromCharCode(199));
        else if (code >= 97 && code <= 122)
            str.push(c.toUpperCase());
        else
            str.push(c);
    }
    return str.join('');
}


function ActiveAgent(id) {
    $("#" + id).click(function () {
        var p = $(this).parent();
        if (p.hasClass("active")) {
            p.removeClass("active");
            p.find('.accordion-content').slideUp();
        } else {
            p.addClass("active");
            p.find('.accordion-content').slideDown();
        }
    });
}

function BilgilendirmePopup(message) {
    var htmlcontainer = $('<div><div class="form-group"><p>' + message + '</p ></div ></div > ').html();
    var options = {
        size: "medium",
        content: {
            html: htmlcontainer
        }
    };
    AxaLibrary.OpenDialog($("#CustomDialog"), options);
    $("#CustomDialog .modal-title").css("color", "red");
    $("#CustomDialog .modal-footer").css("text-align", "center");
    $("#CustomDialog .close").css("display", "none");
}


function SelectAgent(id) {
    $("#" + id).click(function () {
        var $t = $(this);
        var p = $t.parents("li");
        if ($t.hasClass("btn-cancel")) {
            $t.removeClass("btn-cancel").text("Seç");
            p.removeClass("selected");
        } else {
            var seciliAcente = $("#dvAgents").find(".agencyList").find("li.selected");
            //seçilen acentenin dışındaki daha önceden seçilmiş acenteler pasif hale getiriliyor.
            for (var i = 0; i < seciliAcente.length; i++) {
                if ($(seciliAcente[i]) != $t) {
                    $(seciliAcente[i]).removeClass("selected");
                    $(seciliAcente).find('.btn-accordion').removeClass("btn-cancel").text("Seç");
                }
            }
            $t.addClass("btn-cancel").text("Temizle");
            p.addClass("selected");
        }

        var acente_no = id.substr(6, id.length);

        try {
            dataLayer.push({
                event: 'acente_secim',
                "acente_il": $("#hdnacente_il" + acente_no).val(),
                "acente_ilce": $("#hdnacente_ilce" + acente_no).val(),
                "acente": $("#id_" + acente_no).html()
            });
        } catch (e) {
        }



        return false;
    });
}

function RefreshCaptcha() {
    $('#captcha').attr('src', AppBaseUrl + "GenelIslemler/CaptchaImage?r='" + Math.random());
}

function SetAndGetAgent(pid, kisiBilgi) {
    var Url = genelIslemlerApiBaseUrl + "/getAcenteBilgi";
    var kullaniciBilgi = { acenteKotasyonUrl: pid, genelbilgi: kisiBilgi };
    AxaLibrary.ExecuteApi(Url, "POST", kullaniciBilgi, function (data) {
        if (data.Success) {
            $("#logo").css('background-image', 'none');
            $("#logo").html(data.Data).addClass("agencylogo");
            $('#axaLink').attr("href", "#");
        }
        else {
            $("#logo").removeAttr("style");
        }
    }, function (xhr) {
        toastr.error('Acente bilgileri getirilirken hata oluştu.');
    });
}



function SetAgentLogo(uygulamaTip) {
    if ($.QueryString["urlid"] !== undefined) {
        SetAndGetAgent($.QueryString["urlid"], uygulamaTip);
    }
    else {
        SetAndGetAgent('', uygulamaTip);
    }
}

function StringBuilder(value) {
    this.strings = new Array();
    if (value) { this.append(value); }
}

// Appends the given value to the end of this instance.
StringBuilder.prototype.append = function (value) {
    if (value) {
        this.strings.push(value);
    }
}

// Clears the string buffer
StringBuilder.prototype.clear = function () {
    this.strings.length = 1;
}

StringBuilder.prototype.hasData = function () {
    return this.strings.length >= 1;
}

// Converts this instance to a String.
StringBuilder.prototype.toString = function () {
    // var List = document.createElement('ul');
    var list = '<ul><li>' + this.strings.join('</li><li>') + '</li></ul>';
    return list;
}

function SearchItem(source, searchTerm) {
    var result = [];
    if (searchTerm != undefined) {
        for (var i = 0; i < source.length; i++) {
            if (source[i].text.indexOf(searchTerm.toTRUppercase()) >= 0) {
                result.push(source[i]);
            }
        }
    }
    else {
        return source;
    }
    return result;
}

//Kullanicinin daha onceden calismis oldugu acenteler varsa onu listeler.
function GetAgentInformation(tip) {
    var Url = genelIslemlerApiBaseUrl + '/DahaOnceCalisilanAcenteler';
    AxaLibrary.ExecuteApi(Url, "POST", tip, function (msg) {
        if (!msg.Success) {
            if (msg.Data == null) {
                $(".agencySelect b").first().hide();
                $(".agencySelect div").first().hide();
            }
            toastr.error(msg.Message);

            return;
        }
        else {
            $("#dvAgents").show();
            if (msg.Data != null) {

                var agentData;

                if (tip.uygulamaTip == "SagligimTamam") {
                    agentData = JSON.parse(msg.Data).Table1;
                }
                else {
                    agentData = JSON.parse(msg.Data).io_cursor;
                }
                
                if (agentData === null) {
                    $("#dvOldAgents").hide();
                }
                else {

                    $("#mustAgent").html("");
                    $("#mustAgent").append("<ul class='item-list'>");
                    $(agentData).each(function (index, element) {
                        var RandomAgentNo = element.HAYATACENTE_NO + Math.floor(Math.random() * 50)
                        var agentNumber = element.HAYATACENTE_NO;
                        $("#mustAgent").append("<li>" +
                            "<div  class='accordion-item'>" +
                            "<h5 class='title' id='id_" + agentNumber + "'>" + element.AD + "</h5>" +
                            "<i class='accordion-item-arrow'></i>" +
                            "<div class='accordion-content'>" +
                            element.ADRES +
                            "<br />" + element.TEL1 +
                            "<a style='margin-left:15px' class='btn-show-map' href='#' onclick=ShowCoordinates('" + agentNumber + "')  >Haritada göster</a>" +
                            "</div>" +
                            "</div>" +
                            "<a href='#' class='btn-accordion' id='id_btn" + RandomAgentNo + "'>Seç</a>" +
                            "<input type='hidden' id='hdnacente' value='" + agentNumber + "'/>" +
                            "<input type='hidden' id='hdnacente_il" + agentNumber + "'  value = '" + element.IL + "' /> " +
                            "<input type='hidden' id='hdnacente_ilce" + agentNumber + "'  value='" + element.ILCE + "'/>" +
                            "</li>");

                        ActiveAgent("id_" + RandomAgentNo);
                        SelectAgent("id_btn" + RandomAgentNo);
                    });

                    $("#mustAgent").append("</ul>");

                    //sessiondaki partaj numarası ile ilişkili olan kayıt işaretlenir.
                    var currentAgentNumber = msg.Message;
                    if (currentAgentNumber != null) {
                        var agents = $("#dvAgents").find(".agencyList").find("li");
                        for (var i = 0; i < agents.length; i++) {
                            var hiddenAgent = $(agents[i]).find("input[id='hdnacente']");
                            if (currentAgentNumber == hiddenAgent.val()) {
                                $(agents[i]).find('.btn-accordion').addClass("btn-cancel").text("Temizle");
                                $(agents[i]).addClass('selected');
                                break;
                            }
                        }
                    }

                }
            }
            else {
                $("#dvOldAgents").hide();

            }            
        }
    }, function (xhr) {
        toastr.error('Acente listesi getirilirken hata oluştu.');
        $('#hemenOdeSelect').hide();
    });

    GetAgentCityList();

    //$("#city").on('change', function (e) {
    //    $("#district").select2("data", null);
    //    e.preventDefault();
    //});

    $(".otherAgencySearch").button().on("click", function () {
        var city;
        //var district;
        if ($("#city").val() == '') {
            city = null;
        }
        else {
            city = $("#city").val();
        }

        try {
            dataLayer.push({
                event: 'acente_ara',
                acente_il: city
                /*acente_ilce: district*/
            });

        } catch (e) {
            //
        }
        /*SearchProducers(city, district, $("#agentName").val(), tip);*/
        SearchProducers(city, $("#agentName").val(), tip);
    });

    $(".btn-red small btn-type1").button().on("click", function () {
        var city;
        /*var district;*/

        if ($("#city").val() == '') {
            city = null;
        }
        else {
            city = $("#city").val();
        }
        //if ($("#district").val() == '') {
        //    district = null;
        //}
        //else {
        //    district = $("#district").val();
        //}
        /*SearchProducers(city, district, $("#agentName").val(), tip);*/
        SearchProducers(city, $("#agentName").val(), tip);
    });
}

//Sadece tanımlı acentelerin bağlı oldukları illeri döndürür.
function GetAgentCityList() {
    var cityList;
    $("#city").select2({
        placeholder: "İl seçimini yapınız...",
        allowClear: true,
        ajax: {
            url: genelIslemlerApiBaseUrl + "/AgentCityList",
            method: "GET",
            dataType: 'json',
            delay: 250,
            data: null,
            headers: { "X-XSRF-Token": AxaLibrary.GetToken() },
            processResults: function (msg, params) {
                var searchTerm = params.term;
                var cityList = $.map(msg.Data, function (Item, Index) {
                    return { id: Item.Text_Id, text: Item.Text_Value }
                });
                return {
                    results: SearchItem(cityList, searchTerm)
                };
            },
        },
        cache: true
    });
}


//Sadece tanımlı acentelerin bağlı oldukları ilçeleri döndürür.
function GetAgentDistrictList(cityCode) {
    $("#district").val('');
    var city = { Text_Value: cityCode };

    $("#district").select2({
        placeholder: "İlçe seçimini yapınız...",
        allowClear: true,
        ajax: {
            url: genelIslemlerApiBaseUrl + "/AgentDistrictList",
            method: "GET",
            contentType: 'application/json',
            dataType: "json",
            delay: 250,
            data: city,
            headers: { "X-XSRF-Token": AxaLibrary.GetToken() },
            processResults: function (data, params) {
                var searchTerm = params.term;
                var districtList = $.map(data.Data, function (Item, Index) {
                    return { id: Item.Text_Id, text: Item.Text_Value }
                });
                return {
                    results: SearchItem(districtList, searchTerm)
                };
            }
        },
    });
}

//Il,ilçe ve acente adı ile acenteleri filtreler.
//function SearchProducers(agentCity, agentDistrict, agentName, tip) {
//    if (agentCity != null) {
//        var Url = genelIslemlerApiBaseUrl + "/AcenteArama";
//        var kullaniciBilgi = {
//            AcenteBilgi: {
//                "ilID": agentCity,
//                "ilceID": agentDistrict,
//                "acenteAd": agentName
//            },
//            GenelBilgi: tip
//        };

//        $("#webAgent").html("");
//        AxaLibrary.ExecuteApi(Url, "POST", kullaniciBilgi, function (msg) {
//            if (!msg.Success) {
//                toastr.error('Aradığınız il/ilçede acentemiz bulunmamaktadır.');
//                $("#webAgent").hide();
//            }
//            else {
//                if (msg.Data != null) {

//                    var agentData;

//                    if (tip.uygulamaTip == "SagligimTamam") {
//                        agentData = JSON.parse(msg.Data).Table1;
//                    }
//                    else {
//                        agentData = JSON.parse(msg.Data).io_cursor;
//                    }

//                    if (agentData != null) {
//                        $("#webAgent").append("<ul class='item-list list-type1'>");
//                        $(agentData).each(function (index, element) {
//                            var agentNumber = element.HAYATACENTE_NO;
//                            $("#webAgent").append("<li>" +
//                                "<div  class='accordion-item'>" +
//                                "<h5 class='title' id='id_" + agentNumber + "' >" + element.AD + "</h5>" +
//                                //"<p>" + element.AD + "</p>" +
//                                "<i class='accordion-item-arrow'></i>" +
//                                "<div class='accordion-content'>" +
//                                element.ADRES +
//                                "<br />" + element.TEL1 +
//                                "<a  style='margin-left:15px' class='btn-show-map' href='#' onclick=ShowCoordinates('" + agentNumber + "')  >Haritada göster</a>" +
//                                "</div>" +
//                                "</div>" +
//                                "<a href='#' class='btn-accordion' id='id_btn" + agentNumber + "'>Seç</a>" +
//                                "<input type='hidden' id='hdnacente' value='" + agentNumber + "'/>" +
//                                "<input type='hidden' id='hdnacente_il" + agentNumber + "'  value = '" + element.IL + "' /> " +
//                                "<input type='hidden' id='hdnacente_ilce" + agentNumber + "'  value='" + element.ILCE + "'/>" +
//                                "</li>");
//                            ActiveAgent("id_" + agentNumber);
//                            SelectAgent("id_btn" + agentNumber);
//                        });

//                        $("#webAgent").append("</ul>");
//                        $("#webAgent").removeClass("hidden");
//                        $("#hemenOdeSelect").removeClass("hidden");
//                        $("#hemenOdeSelect").show();
//                        $('#webAgent').show();


//                        //  ActiveAgent($("#webAgent"));
//                        //  SelectAgent($("#webAgent"));
//                    }
//                    else {
//                        toast.error('Arama ile eşleşen bir kayıt bulunamadı');
//                    }
//                }
             
//            }
//        }, function (xhr) {
//            toastr.error('Acente listesi getirilirken hata oluştu.');
//        }, true);

//    }
//    else {
//        toastr.error('Lütfen acente araması yaparken il seçimi de yaparak ilerleyiniz.') //   aradığınız acentenin adını yazınız veya ekrandan il ilçe seçimi yaparak ilerleyiniz.');
//        $("#webAgent").html("");
//        $("#webAgent").hide();
//    }
//}

function SearchProducers(agentCity, agentName, tip) {
    if (agentCity != null) {
        var Url = genelIslemlerApiBaseUrl + "/AcenteArama";
        var kullaniciBilgi = {
            AcenteBilgi: {
                "ilID": agentCity,
                "acenteAd": agentName
            },
            GenelBilgi: tip
        };

        $("#webAgent").html("");
        AxaLibrary.ExecuteApi(Url, "POST", kullaniciBilgi, function (msg) {
            if (!msg.Success) {
                toastr.error('Aradığınız ilde acentemiz bulunmamaktadır.');
                $("#webAgent").hide();
            }
            else {
                if (msg.Data != null) {

                    var agentData;

                    //if (tip.uygulamaTip == "SagligimTamam") {
                    //    agentData = JSON.parse(msg.Data).Table1;
                    //}
                    //else {
                    //    agentData = JSON.parse(msg.Data).io_cursor;
                    //}

                    agentData = JSON.parse(msg.Data).Table1;

                    if (agentData != null) {
                        $("#webAgent").append("<ul class='item-list list-type1'>");
                        $(agentData).each(function (index, element) {
                            var agentNumber = element.HAYATACENTE_NO;
                            $("#webAgent").append("<li>" +
                                "<div  class='accordion-item'>" +
                                "<h5 class='title' id='id_" + agentNumber + "' >" + element.AD + "</h5>" +
                                //"<p>" + element.AD + "</p>" +
                                "<i class='accordion-item-arrow'></i>" +
                                "<div class='accordion-content'>" +
                                element.ADRES +
                                "<br />" + element.TEL1 +
                                "<a  style='margin-left:15px' class='btn-show-map' href='#' onclick=ShowCoordinates('" + agentNumber + "')  >Haritada göster</a>" +
                                "</div>" +
                                "</div>" +
                                "<a href='#' class='btn-accordion' id='id_btn" + agentNumber + "'>Seç</a>" +
                                "<input type='hidden' id='hdnacente' value='" + agentNumber + "'/>" +
                                "<input type='hidden' id='hdnacente_il" + agentNumber + "'  value = '" + element.IL + "' /> " +
                                /*"<input type='hidden' id='hdnacente_ilce" + agentNumber + "'  value='" + element.ILCE + "'/>" +*/
                                "</li>");
                            ActiveAgent("id_" + agentNumber);
                            SelectAgent("id_btn" + agentNumber);
                        });

                        $("#webAgent").append("</ul>");
                        $("#webAgent").removeClass("hidden");
                        $("#hemenOdeSelect").removeClass("hidden");
                        $("#hemenOdeSelect").show();
                        $('#webAgent').show();


                        //  ActiveAgent($("#webAgent"));
                        //  SelectAgent($("#webAgent"));
                    }
                    else {
                        toast.error('Arama ile eşleşen bir kayıt bulunamadı');
                    }
                }

            }
        }, function (xhr) {
            toastr.error('Acente listesi getirilirken hata oluştu.');
        }, true);

    }
    else {
        toastr.error('Lütfen acente araması yaparken il seçimi de yaparak ilerleyiniz.') //   aradığınız acentenin adını yazınız veya ekrandan il ilçe seçimi yaparak ilerleyiniz.');
        $("#webAgent").html("");
        $("#webAgent").hide();
    }
}


function IlleriDoldur() {
    $("#city").select2({
        placeholder: "İl seçimini yapınız...",
        allowClear: true,
        ajax: {
            url: genelIslemlerApiBaseUrl + "/IlleriDoldur",
            method: "POST",
            dataType: 'json',
            delay: 250,
            data: null,
            headers: { "X-XSRF-Token": AxaLibrary.GetToken() },
            processResults: function (msg, params) {
                var searchTerm = params.term;
                var iller = $.map(msg.Data, function (Item, Index) {
                    return { id: Item.Cities_Id, text: Item.Cities_Name }
                });
                return {
                    results: SearchItem(iller, searchTerm)
                };
            },
        },
        cache: true
    });

    $("#ilSigortaEttiren").select2({
        placeholder: "İl seçimini yapınız...",
        allowClear: true,
        ajax: {
            url: genelIslemlerApiBaseUrl + "/IlleriDoldur",
            method: "POST",
            dataType: 'json',
            delay: 250,
            data: null,
            headers: { "X-XSRF-Token": AxaLibrary.GetToken() },
            processResults: function (msg, params) {
                var searchTerm = params.term;
                var iller = $.map(msg.Data, function (Item, Index) {
                    return { id: Item.Cities_Id, text: Item.Cities_Name }
                });
                return {
                    results: SearchItem(iller, searchTerm)
                };
            },
        },
        cache: true
    });

}


function IlceleriDoldur(ilElement) {
    var ilSelectId = ilElement[0].id;
    var ilKod = ilElement[0].value;
    if (ilSelectId == 'city') {
        $('#ilce').select2({
            placeholder: "İlçe seçimini yapınız...",
            allowClear: true,
            ajax: {
                url: genelIslemlerApiBaseUrl + "/IlceleriDoldur",
                method: "POST",
                dataType: 'json',
                delay: 250,
                data: { Text_Value: ilKod },
                headers: { "X-XSRF-Token": AxaLibrary.GetToken() },
                processResults: function (msg, params) {
                    var searchTerm = params.term;
                    var ilceler = $.map(msg.Data, function (Item, Index) {
                        return { id: Item.CityRegions_Id, text: Item.CityRegions_Name }
                    });
                    return {
                        results: SearchItem(ilceler, searchTerm)
                    };
                },
                error: function (responseData, textStatus, errorThrown) {
                    toast.error(responseData);
                }
            },
            cache: true
        });
    }
    else {
        $('#ilceSigortaEttiren').select2({
            placeholder: "İlçe seçimini yapınız...",
            allowClear: true,
            ajax: {
                url: genelIslemlerApiBaseUrl + "/IlceleriDoldur",
                method: "POST",
                dataType: 'json',
                delay: 250,
                data: { Text_Value: ilKod },
                headers: { "X-XSRF-Token": AxaLibrary.GetToken() },
                processResults: function (msg, params) {
                    var searchTerm = params.term;
                    var ilceler = $.map(msg.Data, function (Item, Index) {
                        return { id: Item.CityRegions_Id, text: Item.CityRegions_Name }
                    });
                    return {
                        results: SearchItem(ilceler, searchTerm)
                    };
                },
            },
            cache: true
        });
    }

}

function ShowCoordinates(agentNumber) {
    if (agentNumber != '') {
        var Url = genelIslemlerApiBaseUrl + "/GetCoordinates?agentNumber=" + agentNumber;

        AxaLibrary.ExecuteApi(Url, "POST", "", function (msg) {
            if (!msg.Success) {
                toastr.error(msg.Message);
            }
            else {
                ShowOnMap(msg.Data[0], msg.Data[1]);
            }
        }, function (xhr) {
            toastr.error('Acente koordinat bilgileri getirilirken hata oluştu.');
        });
    }
}

function ShowOnMap(latitude, longitude) {
    if (latitude != undefined && longitude != undefined) {
        var latlng = new google.maps.LatLng(latitude, longitude);
        var mapOptions = {
            center: latlng,
            zoom: 16,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map($('#map')[0], mapOptions);
        var marker = new google.maps.Marker({
            position: latlng,
            map: map,
            draggable: true
        });

        marker.setMap(map);
        setTimeout(
            function () {
                var center = map.getCenter();
                google.maps.event.trigger(map, "resize");
                map.setCenter(center);
            }
        );

        var modalDialog = $(".modal-dialog");
        // Applying the top margin on modal dialog to align it vertically center
        modalDialog.css("margin-top", Math.max(0, ($(window).height() / 2)));
        $('#mapDiv').show();
    }
}

//function tcSon2Kontrol() {
//    var guid = $("#txtGuid").val();
//    var tcSon2 = $("#tcSon2").val();
//    $.ajax({
//        type: "Post",
//        url: genelIslemlerApiBaseUrl + "/IlleriDoldur",
//        data: null/*{ guid: guid, tcSon2: tcSon2 }*/,
//        dataType: "json",
//        beforeSend: function () {

//        },
//        success: function (result) {
//            if (result.Success) {
//                alert("ok");
//            } else {
//                alert("hata");
//            }
//        },
//        error: function (xhr, status, error) {
//            var err = eval("(" + xhr.responseText + ")");
//            alert(err.Message);
//        }
//    });
//}

function tcSon2Kontrol() {
    var pGuid = $("#txtGuid").val();
    var pSon2 = $("#tcSon2").val();
    //var pCapcha = $("#secure").val();
    var Url = genelIslemlerApiBaseUrl + "/TcSon2Kontrol";
    var tcSon2KontrolObj = { pGuid: pGuid, pTcNoSon2: pSon2 };
    AxaLibrary.ExecuteApi(Url, "POST", tcSon2KontrolObj, function (data) {
        if (data.Success) {
            $('#formValid').hide();
            $('#formBilgi').show();
        }
        else {
            if (data.Data.pTcNoSon2 == "-1") {
                $('#tcHataGuvenlik').hide();
                $('#tcHataSpan').hide();
                $('#tcHataDenemeSpan').show();
            }
            else {
                $('#tcHataGuvenlik').hide();
                $('#tcHataDenemeSpan').hide();
                $('#tcHataSpan').show();
            }
        }
    }, function (xhr) {
        alert('Hata oluştu lütfen daha sonra tekrar deneyiniz..');
    });
}

function musteriOnayBilgiKaydet() {
    if ($('#frmOnay').valid()) {
        var pGuid = $("#txtGuid").val();
        var pCep = $("#cep").val();
        var pMail = $("#email").val();
        var pTcSon2 = $("#tcSon2").val();
        var pCapcha = $("#secure").val();
        //var pIsChecked = $("#notify").is(':checked');
        var pOnay = $('input[name="secim"]:checked', '#formBilgi').val();

        var Url = genelIslemlerApiBaseUrl + "/MusteriOnayBilgiKaydet";
        var musteriOnayObj = { pGuid: pGuid, pCep: pCep, pEmail: pMail, pTcNoSon2: pTcSon2, pCapcha: pCapcha, pOnay: pOnay };
        AxaLibrary.ExecuteApi(Url, "POST", musteriOnayObj, function (data) {
            if (data.Success) {
                $('#formBilgi').hide();
                $('#formOk').show();
            }
            else {
                if (data.Data.pTcNo == "-1") {
                    $('#frmHataGuvenlik').show();
                }
                else {
                    $('#formHata').show();
                }
                RefreshCaptcha();
                $("#secure").val("");
            }
        }, function (xhr) {
            alert('Hata oluştu lütfen daha sonra tekrar deneyiniz..');
            RefreshCaptcha();
            $("#secure").val("");
        });
    }
  
}

function kisiReddet() {
    var pGuid = $("#txtGuid").val();
    var Url = genelIslemlerApiBaseUrl + "/MusteriOnayBilgiReddet";
    var musteriRedObj = { pGuid: pGuid };
    AxaLibrary.ExecuteApi(Url, "POST", musteriRedObj, function (data) {
        if (data.Success) {
            $('#formValid').hide();
            $('#formOk').show();
        }
        else {
            alert("Bir hata oluştu.")
        }
    }, function (xhr) {
        alert('Hata oluştu lütfen daha sonra tekrar deneyiniz..');
    });
}

function CustomValidator() {
    $.extend($.validator.messages, {
        required: "Bu alanın doldurulması zorunludur.",
        pattern: "Geçersiz format",
        remote: "Lütfen bu alanı düzeltin.",
        email: "Lütfen geçerli bir e-posta adresi giriniz.",
        url: "Lütfen geçerli bir web adresi (URL) giriniz.",
        date: "Lütfen geçerli bir tarih giriniz.",
        dateISO: "Lütfen geçerli bir tarih giriniz(ISO formatında)",
        number: "Lütfen geçerli bir sayı giriniz.",
        digits: "Lütfen sadece sayısal karakterler giriniz.",
        creditcard: "Lütfen geçerli bir kredi kartı giriniz.",
        equalTo: "Lütfen aynı değeri tekrar giriniz.",
        accept: "Lütfen geçerli uzantıya sahip bir değer giriniz.",
        maxlength: $.validator.format("Lütfen en fazla {0} karakter uzunluğunda bir değer giriniz."),
        minlength: $.validator.format("Lütfen en az {0} karakter uzunluğunda bir değer giriniz."),
        rangelength: $.validator.format("Lütfen en az {0} ve en fazla {1} uzunluğunda bir değer giriniz."),
        range: $.validator.format("Lütfen {0} ile {1} arasında bir değer giriniz."),
        max: $.validator.format("Lütfen {0} değerine eşit ya da daha küçük bir değer giriniz."),
        min: $.validator.format("Lütfen {0} değerine eşit ya da daha büyük bir değer giriniz.")
    });

    jQuery.validator.addMethod("cepKontrol", function (cep, element) {
        if (cep.substr(0, 1) == '0') {
            cep = cep.substr(1, cep.length);
        }
        cep = cep.replace(/\s/g, "").split('_').join('').trim();
        cep = cep.replace('-', '');
        return cep.length == 12;
    }, "Geçerli bir cep numarası giriniz.");


    jQuery.validator.addMethod("tarihKontrol", function (dogumTarihi, element) {
        var durumKontrol = moment(dogumTarihi, "DD/MM/YYYY", true).isValid();
        return durumKontrol == true;
    }, "Geçerli bir doğum tarihi giriniz.");


    $('#frmgenel').validate({
        rules: {
            tckn: {
                maxlength: 11,
                minlength: 11,
                digits: true,
                required: true
            },
            email: {
                required: true,
                email: true
            },
            cep: {
                required: true,
                cepKontrol: true
            },
            dogumTarihi: {
                required: true,
                tarihKontrol : true
            },
            agree: {
                required: true
            },
            elektronikiletionay: {
                required: true
            },
            secure: {
                required: true
            }
        },
        messages: {
            agree: "Bu alanın işaretlenmesi gerekmektedir",
            elektronikiletionay: "Bu alanın işaretlenmesi gerekmektedir",
            cep: { minlength: "Cep numarası alanınını doldurunuz." },
            tel: { minlength: "Cep numarası alanınını doldurunuz." },
            tckn: { minlength: "TC kimlik numarası alanına 11 değer giriniz." }
        },
        errorClass: "kirmizierror" ,
        errorPlacement: function (error, element) {
            if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                if (element.parent()[0].nodeName == "LI") {
                    error.insertAfter(element.parent()[0]);
                    // element.parent()[0].append(error);
                }
                else {
                    element.parent().children().last().append(error);
                }
            }
            else {
                var sonElement = element.parent().children().last();
                error.insertAfter(sonElement);
            }

        }
    });

    $('#frmgenelLead').validate({
        rules: {
            tckn: {
                maxlength: 11,
                minlength: 11,
                digits: true,
                required: true
            },
            email: {
                required: false,
                email: true
            },
            cep: {
                required: true,
                cepKontrol: true
            },
            dogumTarihi: {
                required: true,
                tarihKontrol: true
            },
            agree: {
                required: true
            },
            elektronikiletionay: {
                required: true
            },
            secure: {
                required: true
            }
        },
        messages: {
            agree: "Bu alanın işaretlenmesi gerekmektedir",
            elektronikiletionay: "Bu alanın işaretlenmesi gerekmektedir",
            cep: { minlength: "Cep numarası alanınını doldurunuz." },
            tel: { minlength: "Cep numarası alanınını doldurunuz." },
            tckn: { minlength: "TC kimlik numarası alanına 11 değer giriniz." }
        },
        errorClass: "kirmizierror",
        errorPlacement: function (error, element) {
            if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                if (element.parent()[0].nodeName == "LI") {
                    error.insertAfter(element.parent()[0]);
                    // element.parent()[0].append(error);
                }
                else {
                    element.parent().children().last().append(error);
                }
            }
            else {
                var sonElement = element.parent().children().last();
                error.insertAfter(sonElement);
            }

        }
    });

    $('#frmOnay').validate({
        rules: {
            email: {
                //required: true,
                email: true
            }
            //,
            //agree: {
            //    required: true
            //}
        },
        messages: {
            agree: "Bu alanın işaretlenmesi gerekmektedir"
        },
        errorPlacement: function (error, element) {
            if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                if (element.parent()[0].nodeName == "LI") {
                    error.insertAfter(element.parent()[0]);
                    // element.parent()[0].append(error);
                }
                else {

                  
                    element.parent().children().last().append(error);
                }
            }
            else {
                var sonElement = element.parent().children().last();
                error.insertAfter(sonElement);
            }
        }
    });
}

var smsTimer;

function setsmsTimer() {
    var timeleft = 120;
    smsTimer = setInterval(function () {
        if (timeleft <= 0) {
            $("#btnSmsTekrar").removeAttr("disabled");
            clearInterval(smsTimer);
        }
        $("#lblKalanSure").html(timeleft);
        timeleft -= 1;
    }, 1000);
}


function SmsDogrulaKotasyon(uygulamaTip) {
    $.unblockUI();
    $("#SmsDialog .modal-title").css("color", "red");
    $("#SmsDialog .modal-footer").css("text-align", "center");
    $("#SmsDialog p").css("font-size", "+=3");
    $("#SmsDialog .close").css("display", "none");

    AxaLibrary.OpenDialog($("#SmsDialog"), {
        caption: "SMS Onay",
        IsCloseable: false,
        content: {
            url: AppBaseUrl + "/SagligimTamam/SmsDogrulama",
            onsuccess: setsmsTimer
        },
        size: "small",
        buttons: [
            {
                title: "Tekrar Gönder",
                attr: { "disabled": true, "id": "btnSmsTekrar", "style": "float:left" },
                click: function () {
                    var smsGuid = "A2EA7E55EFC802A6E0530A3C9D2232BF";
                    if (uygulamaTip == 'BES') {
                        smsGuid = "C0F6E203CC1E0892E0530A3C9D220EAF";
                    }
                    var url = sagligimTamamApiBaseUrl + "/OnaySmsGonderim";
                    AxaLibrary.ExecuteApi(url, "POST", { "": smsGuid }, function (msg) {
                        if (msg.Success) { setsmsTimer(); $("#btnSmsTekrar").attr("disabled", "true"); } else { $("#lblHataMesaj").html("Sms gönderimini tekrar deneyiniz."); clearInterval(smsTimer); }
                    }, function () {
                        $.unblockUI();
                        $("#lblHataMesaj").html("Sms tekrar gönderiminde hata oluştu!");
                    });
                    return false;
                }
            },
            {
                title: "Onay",
                attr: {
                    "id": "btnSmsOnay", "style": "float:right"
                },
                click: function () {
                    $("#lblHataMesaj").html("");
                    if (!$("#txtSmsSifre").val()) {
                        $("#lblHataMesaj").html("Sms kodu girilmelidir");
                        return false;
                    }
                    var url = "";
                    if (uygulamaTip == 'TSS') {
                        url = apiBaseUrl + "/TeklifAl";
                        AxaLibrary.ExecuteApi(url, "POST", { "": $("#txtSmsSifre").val() }, function (msg) {
                            if (!msg.Success) {
                                if (msg.Data == "Sms") {
                                    $("#lblHataMesaj").html(msg.Message);
                                } else {
                                    clearInterval(smsTimer);
                                    $("#SmsDialog").modal("hide");
                                    toastr.error(msg.Message);
                                }
                                RefreshCaptcha();
                                return false;
                            } else {
                                clearInterval(smsTimer);
                                window.location.href = AppBaseUrl + "SagligimTamam/Prim_Detay";
                            }
                        });
                    }
                    else if (uygulamaTip == 'KobiTSS') {
                        url = apiBaseUrl + "/KobiLeadOlustur";
                        AxaLibrary.ExecuteApi(url, "POST", { "": $("#txtSmsSifre").val() }, function (msg) {
                            if (!msg.Success) {
                                if (msg.Data == "Sms") {
                                    $("#lblHataMesaj").html(msg.Message);
                                } else {
                                    clearInterval(smsTimer);
                                    $("#SmsDialog").modal("hide");
                                    toastr.error(msg.Message);
                                }
                                RefreshCaptcha();
                                return false;
                            } else {
                                clearInterval(smsTimer);
                                $("#SmsDialog").modal("hide");
                                RefreshCaptcha();
                                toastr.success('Acentemiz size en kısa zamanda dönüş yapacaktır.');
                            }
                        });
                    }
                    else if (uygulamaTip == 'SulaleIndirimliTSS') {
                        url = sulaleIndirimliApiBaseUrl + "/SulaleIndirimliLeadOlustur";
                        AxaLibrary.ExecuteApi(url, "POST", { "": $("#txtSmsSifre").val() }, function (msg) {
                            if (!msg.Success) {
                                if (msg.Data == "Sms") {
                                    $("#lblHataMesaj").html(msg.Message);
                                } else {
                                    clearInterval(smsTimer);
                                    $("#SmsDialog").modal("hide");
                                    toastr.error(msg.Message);
                                }
                                RefreshCaptcha();
                                return false;
                            } else {
                                clearInterval(smsTimer);
                                $("#SmsDialog").modal("hide");
                                window.location.href = AppBaseUrl + "SulaleIndirimliSagligimTamam/Tesekkur_Basvuru";
                            }
                        });
                    }
                    else if (uygulamaTip == 'BES') {
                        url = apiBaseUrl + "/BESSmsKontrol";
                        AxaLibrary.ExecuteApi(url, "POST", { "": $("#txtSmsSifre").val() }, function (msg) {
                            if (!msg.Success) {
                                if (msg.Data == "Sms") {
                                    $("#lblHataMesaj").html(msg.Message);
                                } else {
                                    clearInterval(smsTimer);
                                    $("#SmsDialog").modal("hide");
                                    toastr.error(msg.Message);
                                }
                                RefreshCaptcha();
                                return false;
                            } else {
                                clearInterval(smsTimer);
                                $("#SmsDialog").modal("hide");
                                var processType = $("#processType option:selected").val();
                                if ($("#agree").is(":checked") && $("#elektronikiletionay").is(":checked")) {
                                    notify = "true";
                                }
                                var parameters = {
                                    "tcNo": $("#tckn").val(),
                                    "cepTel": $("#cep").val(),
                                    "ePosta": $("#email").val(),
                                    "dogumTarihi" : $("#txtDogumTarihi").val(),
                                    "captcha": $("#secure").val(),
                                    "musteriIzin": notify,
                                    "emeklilikSecenek": processType
                                };
                                if (processType === "1") {
                                    SavePolicy(parameters);
                                }
                                else {
                                    RedirectToAgentSelectionPage(parameters);
                                }
                            }
                        });

                    }

                    return false;
                }

            }]
    });

}
