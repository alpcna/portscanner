﻿function SigortaliBilgiGetir() {
    var Url = apiBaseUrl + "/SigortaliBilgiGetir";
    AxaLibrary.ExecuteApi(Url, "POST", "", function (msg) {
        if (!msg.Success) {
            toastr.error(msg.Message);
        } else {
            if (msg.Data.tc != null) {
                $("#tc").val(msg.Data.tc);
            }
            if (msg.Data.cep != null) {
                $("#cepTel").val(msg.Data.cep);
            }
            if (msg.Data.mail != null) {
                $("#eposta").val(msg.Data.mail);
            }
            if (msg.Data.DogumTarihi != null) {
                $("#txtDogumTarihi").val(msg.Data.DogumTarihi);
            }
        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('Sigortalı müşteri bilgilerini getirirken hata oluştu.');

    });
}

function SagligimTamamGiris() {

    $("#txtDogumTarihi").removeClass("form-control");
    $("#txtDogumTarihi").datepicker($.extend({
        showStatus: true,
        duration: 'fast',
        changeMonth: true,
        changeYear: true,
        todayHighlight: true,
        yearRange: '1920:2021',
        minDate: new Date(1920, 1 - 1, 1),
        maxDate: '+30Y',
    }, $.datepicker.regional['tr']));


    $("#txtDogumTarihi").keydown(function (event) {
        if (event.keyCode === 66/*B*/) {
            var v_new_date = new Date();
            $(this).datepicker('setDate', v_new_date);
        }
        else if (event.keyCode === 109/*-*/) {
            var v_new_date1 =
                new Date($(this).datepicker('getDate').getFullYear(),
                    $(this).datepicker('getDate').getMonth(),
                    $(this).datepicker('getDate').getDate());
            //var v_new_date = new Date();
            v_new_date1.setDate(v_new_date1.getDate() - 1);
            $(this).datepicker('setDate', v_new_date1);
        }
        else if (event.keyCode === 107/*+*/) {
            var v_new_date2 =
                new Date($(this).datepicker('getDate').getFullYear(),
                    $(this).datepicker('getDate').getMonth(),
                    $(this).datepicker('getDate').getDate());
            //var v_new_date = new Date();
            v_new_date2.setDate(v_new_date2.getDate() + 1);
            $(this).datepicker('setDate', v_new_date2);
        }
    });


    $('.tab1').on('click', function () {
        $('#customTab1').addClass('customTabActive');
        $('#customTab2').removeClass('customTabActive');
    });

    $('.tab2').on('click', function () {
        $('#customTab2').addClass('customTabActive');
        $('#customTab1').removeClass('customTabActive');
    });
    clearInterval(smsTimer);
    SetAgentLogo({ uygulamaTip: "SagligimTamam" });
    CustomValidator();

    $("#secureCode").click(function () {
        RefreshCaptcha();
    });
    $("#btnTeklifAl").button().on("click", function () {
        ParametreleriKaydet();
    });
    //SigortaliBilgiGetir();
    //RefreshCaptcha();
}
function SigortaEttirenGiris() {
    $("#btnSigortaEttiren").button().on("click", function () {
        var TCKNo = $("#tckn").val();
        SigortaEttirenFarkliTeklifOlustur(TCKNo);
        return false;
    });
}
function SigortaEttirenFarkliTeklifOlustur(tcno) {
    var Url = apiBaseUrl + "/SigortaEttirenFarkliTeklifOlustur";
    var parametre = {
        "tcNo": tcno
    };

    AxaLibrary.ExecuteApi(Url, "POST", parametre, function (data) {
        if (!data.Success) {
            toastr.error(data.Message);
        }
        else {
            window.location.href = AppBaseUrl + data.Data;
        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('Teklif oluşturulurken hata oluştu.');
    });
}
function SureHesapla() {
    var timer = 180;
    setInterval(function () {
        if (timer > -1) {
            $('#lblKalanSure').text(timer);
            $("#btnTekrarGonder").addClass("invisible");
        }
        if (timer == 0) {
            $("#btnTekrarGonder").removeClass("invisible");
        }
        if (--timer < 0) {
            timer = --timer;
        }
    }, 1000);
}
function SigortaliVeSigortaEttirenEsitle() {
    var Url = apiBaseUrl + "/SigortaliVeSigortaEttirenEsitle";
    AxaLibrary.ExecuteApi(Url, "POST", "", function (msg) {
        if (!msg.Success) {
            toastr.error('İşlem sırasında hata oluştu. Lütfen tekrar deneyin.');
        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('İşlem sırasında hata oluştu. Lütfen tekrar deneyiniz.');
    });
}
function KobiAra() {
    if ($('#frmgenel').valid()) {
        var notify = false;
        if ($("#agree").is(":checked")  && $("#elektronikiletionay").is(":checked")) {
            notify = true;
        }
        var sigortali = {
            tcNo: $("#tc").val(),
            cepTel: $("#cep").val().replace(/ /g, ''),
            ePosta: $("#eposta").val(),
            captcha: $("#secure").val(),
            musteriIzin: notify,
            dogumTarihi: $("#txtDogumTarihi").val()

        };

        var Url = apiBaseUrl + "/KobiAra";
        AxaLibrary.ExecuteApi(Url, "POST", sigortali, function (msg) {
            if (!msg.Success) {
                toastr.error(msg.Message);
            }
            else {
                SmsDogrulaKotasyon('KobiTSS');
                // toastr.success('Acentemiz size en kısa zamanda dönüş yapacaktır.');
            }
        }, function (xhr) {
            $.unblockUI();
            toastr.error("İşlem sırasında hata oluştu. Lütfen tekrar deneyin");
            RefreshCaptcha();
        });
    }
}
function ParametreleriKaydet() {
    if ($('#frmgenel').valid()) {
        if ($("#agree").is(":checked")  && $("#elektronikiletionay").is(":checked")) {
            var url = apiBaseUrl + '/ParametreleriKaydet';
            var parametreler = {
                "tcNo": $("#tc").val(),
                "cepTel": $("#cepTel").val().replace(/ /g, ''),
                "ePosta": $("#eposta").val(),
                "dogumTarihi": $("#txtDogumTarihi").val(), 
                "captcha": $("#secure").val(),
                "musteriIzin": true,
                "hopiKodu": $("#hopiKodu").val()
            };
            AxaLibrary.ExecuteApi(url, "POST", parametreler, function (msg) {
                if (msg.Success) {
                    //try {
                    //    dataLayer.push({
                    //        event: 'lead',
                    //        lead_id: msg.Data,
                    //        lead_product: 'Sağlığım Tamam',
                    //        lead_category: 'Sağlık'
                    //    });
                    //} catch (e) { }
                    if (msg.Data) {
                        SmsDogrula(msg.Data);
                    } else {
                        window.location.href = AppBaseUrl + "SagligimTamam/Prim_Detay";
                    }
                }
                else {
                    toastr.error(msg.Message);
                    RefreshCaptcha();
                }
            }, function (xhr, ajaxOptions, thrownError) {
                $.unblockUI();
                toastr.error('Sigortalı oluşturulurken hata oluştu. ');
            });
        }
        else {
            toastr.error("Devam edebilmek için \"Gizlilik Politikasını ve Bilgilendirme Yönetmeliğini okudum, kabul ediyorum.\" seçeneğini seçmeniz gerekmektedir.");
        }
    }
}

function PrimGetir() {
    $("[data-toggle=popover]").popover();

    if ($(".proposal-tabs").length > 0) {
        $(".proposal-tabs .proposal-tab").click(function () {
            var $t = $(this);
            $(".proposal-tabs .proposal-tab").removeClass("active");
            $(".proposal").removeClass("active");
            $t.addClass("active");
            $(".proposal." + $t.data("tab")).addClass("active");
        });
        $(".proposal-tabs .proposal-tab:first-child").click();
    }
    var Url = apiBaseUrl + "/PrimListesiOlustur";
    AxaLibrary.ExecuteApi(Url, "POST", "", function (msg) {
        if (msg.Success) {
            if (msg.Data != null && msg.Data.length>0) {
                var Pesin893 = $.grep(msg.Data, function (item, index) {
                    return item.UrunKodu == "893";
                })[0].Pesin;
                var Pesin693 = $.grep(msg.Data, function (item, index) {
                    return item.UrunKodu == "693";
                })[0].Pesin
                $(".yatarak").html(Pesin893);
                $(".yatarak_ayakta").html(Pesin693);
            }

            if (msg.Message) {
                toastr.error(msg.Message);
            }
            if (msg.Data.AcenteMi == "true") {
                $("#logo").css('background-image', 'none');
                $("#logo").html(msg.Data.AcenteAd).addClass("agencylogo");

                $("#btnGeri").css("left", "100px");
                $("#btnGeri").button().on("click", function () {
                    window.location.href = AppBaseUrl + "SagligimTamam/Genel_Bilgiler";
                });
            }
        }
        else {
            var htmlcontainer = $('<div><div class="form-group"><p>' + msg.Message + '</p ></div ></div > ').html();
            var options = {
                size: "medium",
                content: {
                    html: htmlcontainer
                },
                buttons: [{
                    title: 'Tamam', click: function () {
                        window.location.href = AppBaseUrl + "SagligimTamam/Genel_Bilgiler";
                    }
                }],
            };
            AxaLibrary.OpenDialog($("#CustomDialog"), options);
            $("#CustomDialog .modal-title").css("color", "red");
            $("#CustomDialog .modal-footer").css("text-align", "center");
            $("#CustomDialog p").css("font-size", "+=3");
            $("#CustomDialog .close").css("display", "none");


        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('Prim listesi getirilirken hata oluştu.');
    });

    $("#btnPrimDevam").button().on("click", function () {
        if ($('#dvFiyatCalismasi').is(':visible')) {
            var PayPlan = { "odemePlanId": $('input[name="price"]:checked', '#priceList').val() };
            var PayPlanElementId = $('input[name="price"]:checked', '#priceList')[0].id;
            var Prim = $('#' + PayPlanElementId.replace('chk', 'txt')).html();
            try {
                dataLayer.push({
                    "event": 'fiyat_calismasi',
                    "product_category": 'Sağlık',
                    "product_name": 'Sağlığım Tamam',
                    "product_price": Prim,
                    "fiyat_secenegi": PayPlanElementId.replace('chk', '')
                });
            } catch (e) {

            }
        }
        else {
            var seciliPoliceSecenekIndex = $(".proposal .btn-select.selected").data("id");
            if (seciliPoliceSecenekIndex != null) {
                var Url = apiBaseUrl + "/UrunSecimiYap";
                var param = {
                    "seciliPoliceIndex": seciliPoliceSecenekIndex
                };
                AxaLibrary.ExecuteApi(Url, "POST", param, function (msg) {
                    if (msg.Success) {
                        window.location.href = AppBaseUrl + "SagligimTamam/Iletisim_Bilgileri";
                    }
                });
            } else {
                toastr.error('Ürün seçimi yapmalısınız!');
            }
        }
    });
}

function SecilenPrimGetir() {
    var Url = apiBaseUrl + "/SecilenPrimGetir";
    AxaLibrary.ExecuteApi(Url, "POST", "", function (msg) {
        if (msg.Success) {
            $("#txt5Taksit").html(msg.Data.Pesin25);
            $("#txt10Taksit").html(msg.Data.Taksit10);
            $("#txtPesin").html(msg.Data.Pesin);
        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('Prim listesi getirilirken hata oluştu.');
    });

}

function MusteriBilgiGetir() {
    var Url = apiBaseUrl + "/MusteriBilgiGetir";
    AxaLibrary.ExecuteApi(Url, "POST", "", function (msg) {
        if (msg.Success) {
            if (msg.Data.AcenteKotasyonMu == true) {
                $("#hdnAcenteKotasyon").val(msg.Data.musteriacente);
                $("#logo").css('background-image', 'none');
                $("#logo").html(msg.Data.AcenteAd).addClass("agencylogo");

                $('#hdnAcenteKotasyon').addClass("hidden");
                $('#dvHemenOdeAcenteKotasyon').removeClass("hidden");

                $('#dvHemenOde').removeClass("hidden");
                $('#hemenOde').removeClass("hidden");
                //TahsilataGonder();

            }
            else {
                $("#hdnAcenteKotasyon").removeClass("hidden");
                $('#dvHemenOdeAcenteKotasyon').addClass("hidden");

                $('#dvHemenOde').removeClass("hidden");
                $('#hemenOde').removeClass("hidden");

                $('#hdnAcenteKotasyon').removeClass("hidden");

                var durum = $('input[name="usertype"]:checked').val();
                if (durum == "true") {
                    var SigortaEttiren = {
                        tcNo: $("#txtSigortaEttirenTC").val(),
                        cepTel: $("#txtSigortaEttirenCep").val(),
                        ePosta: $("#txtSigortaEttirenEmail").val(),
                        dogumTarihi: $("#txtSigortaEttirenDogumTarihi").val()
                    };
                    var Url = apiBaseUrl + "/SigortaEttirenOlustur";
                    AxaLibrary.ExecuteApi(Url, "POST", SigortaEttiren, function (msg) {
                        if (!msg.Success) {
                            toastr.error(msg.Message);
                        }
                        else {
                            $("#hdnAcenteKotasyon").removeClass("hidden");
                            $('mustAgent').html("");
                            GetAgentInformation({ uygulamaTip: "SagligimTamam" });
                        }
                    }, function (xhr) {
                        $.unblockUI();
                        toastr.error('Sigorta Ettireni kaydederken hata oluştu.');
                    });
                }
            }
            $("#txtMail").val(msg.Data.mail);
            if (msg.Data.sigortaEttiren_tc != msg.Data.tc) {
                $("#txtSigortaEttirenTC").val(msg.Data.sigortaEttiren_tc);
                $("#txtSigortaEttirenCep").val(msg.Data.sigortaEttiren_cep);
                $("#txtSigortaEttirenEmail").val(msg.Data.sigortaEttiren_email);

                $('.btn-other-user-info').trigger('click');
                $('label[for="crEvet"]').trigger('click');
            }
            IlleriDoldur();
            GetAgentInformation({ uygulamaTip: "SagligimTamam" });
            //$("#city").on('change', function (e) {
            //    $("#district").select2("data", null);
            //    e.preventDefault();
            //});

            $("#ilSigortaEttiren").on('change', function (e) {
                $("#ilceSigortaEttiren").select2("data", null);
                e.preventDefault();
            });

            CustomValidator();
        }
        else {
            toastr.error(msg.Message);
        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('Müşteri bilgileri getirilirken hata oluştu.');
    });

}
function OdemePlaniDegistir(PayPlan, State) {
    var s = $("#dvAgents").find(".agencyList").find("li.selected");
    if (s.find("input[id='hdnacente']").val() || $("#hdnAcenteKotasyon").val()) {
        var acenteNo;
        if (s.find("input[id='hdnacente']").val()) {
            acenteNo = s.find("input[id='hdnacente']").val();
        }
        else {
            acenteNo = $("#hdnAcenteKotasyon").val();
        }
        if (!acenteNo) {
            toastr.error("Lütfen acente seçiniz");
            return;
        }
        try {
            dataLayer.push({
                "event": 'acente_secim',
                "acente_no": acenteNo
            });
        } catch (e) {

        }
    } else {
        toastr.error("Lütfen acente seçiniz");
        return;
    }
    var SigortaEttiren = null;
    var durum = $('input[name="usertype"]:checked').val();
    if (durum == "true") {
        if ($("#txtSigortaEttirenTC").val() && $("#txtSigortaEttirenEmail").val() && $("#txtSigortaEttirenCep").val() && $("#txtSigortaEttirenDogumTarihi").val() ) {
            SigortaEttiren = {
                tckn: $("#txtSigortaEttirenTC").val(),
                cep: $("#txtSigortaEttirenCep").val(),
                email: $("#txtSigortaEttirenEmail").val(),
                dogumTarihi: $("#txtSigortaEttirenDogumTarihi").val()
            };
        } else {
            toastr.error("Sigorta Ettiren bilgilerini giriniz");
            return;
        }
    } else {
        SigortaEttiren = {};
    }

    var policeBilgi = {
        "sigortaliemail": $("#txtMail").val(),
        "sigortaEttiren": SigortaEttiren,
        "SecilenAcente": acenteNo,
        "SecilenOdemePlani": $('input[name="price"]:checked', '#priceList').val(),
        "sigortaetfarkli": durum == "true"
    };
    var url = apiBaseUrl + "/UpdateSelectedPolicyStatus";
    AxaLibrary.ExecuteApi(url, "POST", policeBilgi, function (msg) {
        if (!msg.Success) {
            toastr.error(msg.Message);
        } else {
            window.location.href = msg.Data;
        }
    }, function (msg) {
        $.unblockUI();
        toastr.error(msg.statusText);
    });
}
function IletisimBilgileriGiris() {


    //$("#txtSigortaEttirenDogumTarihi").removeClass("form-control");
    //$("#txtSigortaEttirenDogumTarihi").datepicker($.extend({
    //    showStatus: true,
    //    duration: 'fast',
    //    changeMonth: true,
    //    changeYear: true,
    //    todayHighlight: true,
    //    yearRange: '1920:2021',
    //    minDate: new Date(1920, 1 - 1, 1),
    //    maxDate: '+30Y',
    //}, $.datepicker.regional['tr']));


    //$("#txtSigortaEttirenDogumTarihi").keydown(function (event) {
    //    if (event.keyCode === 66/*B*/) {
    //        var v_new_date = new Date();
    //        $(this).datepicker('setDate', v_new_date);
    //    }
    //    else if (event.keyCode === 109/*-*/) {
    //        var v_new_date1 =
    //            new Date($(this).datepicker('getDate').getFullYear(),
    //                $(this).datepicker('getDate').getMonth(),
    //                $(this).datepicker('getDate').getDate());
    //        //var v_new_date = new Date();
    //        v_new_date1.setDate(v_new_date1.getDate() - 1);
    //        $(this).datepicker('setDate', v_new_date1);
    //    }
    //    else if (event.keyCode === 107/*+*/) {
    //        var v_new_date2 =
    //            new Date($(this).datepicker('getDate').getFullYear(),
    //                $(this).datepicker('getDate').getMonth(),
    //                $(this).datepicker('getDate').getDate());
    //        //var v_new_date = new Date();
    //        v_new_date2.setDate(v_new_date2.getDate() + 1);
    //        $(this).datepicker('setDate', v_new_date2);
    //    }
    //});


    SecilenPrimGetir();
    MusteriBilgiGetir();

    $('.btnAgencyDelete').click(function (e) {
        $("#city").val('').trigger('change');
        $('#agentName').val('');
        $("#hemenOdeSelect").addClass('hidden');
        e.preventDefault();
    });

    $("#btnHemenOde").button().on("click", function () {
        var PayPlan = {
            "odemePlanId": $('input[name="price"]:checked', '#priceList').val()
        };
        OdemePlaniDegistir(PayPlan, 1);
        return false;
    });

    $("#btnHemenOdeAcenteKotasyon").button().on("click", function () {
        var PayPlan = { "odemePlanId": $('input[name="price"]:checked', '#priceList').val() };
        OdemePlaniDegistir(PayPlan, 1);

        var sigortaliTipi = 'sigorta ettirenle aynı';
        if ($('input[name=usertype]:checked').val() == "true") {
            sigortaliTipi = 'sigorta ettirenden farklı';
        }
        try {
            dataLayer.push({
                "event": 'satin_alma_tipi',
                "satin_alma_tipi": 'acente',
                "sigortali_tipi": sigortaliTipi
            });

        } catch (e) {

        }
        return false;
    });

    $('.close').button().on("click", function () {
        $('#mapDiv').hide();
    });

    $("input:radio[name='usertype']").on("change", function () {
        if ($(this).val() == "false") {
            //Sigortalı ve sigorta ettiren bilgileri birbirine eşitleniyor.
            SigortaliVeSigortaEttirenEsitle();
        }
    });
}
function TahsilataGonder() {
    var sigortaliTipi = 'sigorta ettirenle aynı';
    var durum = $('input[name="usertype"]:checked').val();
    if (durum == "true") {
        sigortaliTipi = 'sigorta ettirenden farklı';

        var SigortaEttiren = {
            tcNo: $("#txtSigortaEttirenTC").val(),
            cepTel: $("#txtSigortaEttirenCep").val(),
            ePosta: $("#txtSigortaEttirenEmail").val()
        };
        SigortaEttirenOlustur(SigortaEttiren);
    }
    else {
        HemenOde();
    }
    try {
        dataLayer.push({
            "event": 'satin_alma_tipi',
            "satin_alma_tipi": 'acente',
            "sigortali_tipi": sigortaliTipi
        });
    } catch (e) {

    }
}
function SigortaEttirenOlustur(SigortaEttiren) {
    var Url = apiBaseUrl + "/SigortaEttirenOlustur";
    AxaLibrary.ExecuteApi(Url, "POST", SigortaEttiren, function (msg) {
        if (!msg.Success) {
            toastr.error(msg.Message);
        }
        else {
            HemenOde();
        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('Sigorta Ettireni kaydederken hata oluştu.');
    });
}
function HemenOde() {
    var s = $("#dvAgents").find(".agencyList").find("li.selected");

    if ($("#hdnAcenteKotasyon").val() == "") {
        if (s.length == 0) {
            toastr.error("Lütfen acente seçiniz");
            return false;
        }
    }
    if (s.find("input[name='hdnacente']").val() || $("#hdnAcenteKotasyon").val()) {
        var acenteNo;
        if (s.find("input[name='hdnacente']").val()) {
            acenteNo = s.find("input[name='hdnacente']").val();
        }
        else {
            acenteNo = $("#hdnAcenteKotasyon").val();
        }
        try {
            dataLayer.push({
                "event": 'acente_secim',
                "acente_no": acenteNo
            });
        } catch (e) {

        }
        if (!acenteNo) {
            toastr.error('Acente bilgisi seçilmelidir');
            return;
        }

        var ivrParametreler = {
            sigortali: {
                ePosta: $("#txtMail").val()
            },
            sigortaEttiren: {
                tcNo: $("#txtSigortaEttirenTC").val(),
                cepTel: $("#txtSigortaEttirenCep").val(),
                ePosta: $("#txtSigortaEttirenEmail").val()

            },
            satinAlmaSecenek: "acente",
            secilenAcente: acenteNo
        }
        if (acenteNo != "") {
            IVRKaydiOlustur(ivrParametreler);
        }

    }
}
function IVRKaydiOlustur(PoliceDetayBilgi) {
    var Url = apiBaseUrl + "/IVRKaydiOlustur";
    AxaLibrary.ExecuteApi(Url, "POST", PoliceDetayBilgi, function (msg) {
        if (msg.Success) {
            window.location.href = msg.Data;
            return false;
        }
        else {
            toastr.error('Girmiş olduğunuz bilgilerle online teklif oluşturamamaktayız. Lütfen acentenizle irtibata geçiniz.');
        }
    }, function (xhr) {
        $.unblockUI();
        toastr.error('Girmiş olduğunuz bilgilerle online teklif oluşturamamaktayız. Lütfen acentenizle irtibata geçiniz.');
    });
}
function SulaleIndirimLead() {
    if ($('#frmgenel').valid()) {
        var notify = false;
        if ($("#agree").is(":checked") && $("#elektronikiletionay").is(":checked")) {
            notify = true;
        }
        var sigortali = {
            tcNo: $("#tc").val(),
            cepTel: $("#cep").val().replace(/ /g, ''),
            ePosta: $("#eposta").val(),
            dogumTarihi: $("#dogumTarihi").val(),
            captcha: $("#secure").val(),
            musteriIzin: notify
        };

        var Url = sulaleIndirimliApiBaseUrl + "/SulaleIndirimliSigortaKayit";
        AxaLibrary.ExecuteApi(Url, "POST", sigortali, function (msg) {
            if (!msg.Success) {
                toastr.error(msg.Message);
            }
            else {
                window.location.href = AppBaseUrl + "SulaleIndirimliSagligimTamam/Tesekkur_Basvuru";
            }
        }, function (xhr) {
            toastr.error("İşlem sırasında hata oluştu. Lütfen tekrar deneyin");
            RefreshCaptcha();
        });
    }
}

var smsTimer;

function setsmsTimer() {
    var timeleft = 120;
    smsTimer = setInterval(function () {
        if (timeleft <= 0) {
            $("#btnSmsTekrar").removeAttr("disabled");
            clearInterval(smsTimer);
        }
        $("#lblKalanSure").html(timeleft);
        timeleft -= 1;
    }, 1000);
}

function SmsDogrula(data) {
    $.unblockUI();
    $("#SmsDialog .modal-title").css("color", "red");
    $("#SmsDialog .modal-footer").css("text-align", "center");
    $("#SmsDialog p").css("font-size", "+=3");
    $("#SmsDialog .close").css("display", "none");
    AxaLibrary.OpenDialog($("#SmsDialog"), {
        caption: "SMS Onay",
        IsCloseable : false,
        content: {
            url: AppBaseUrl + "/SagligimTamam/SmsDogrulama",
            onsuccess: setsmsTimer
        },
        size : "small",
        buttons: [
            {
                title: "Tekrar Gönder",
                attr: { "disabled": true, "id": "btnSmsTekrar","style":"float:left" },
                click: function () {

                    var url = apiBaseUrl + "/OnaySmsGonder";
                    AxaLibrary.ExecuteApi(url, "POST", {}, function (msg) {
                        if (msg.Success) { setsmsTimer(); $("#btnSmsTekrar").attr("disabled", "true"); } else { $("#lblHataMesaj").html("Sms gönderimini tekrar deneyiniz."); clearInterval(smsTimer); }
                    }, function () {
                        $.unblockUI();
                        $("#lblHataMesaj").html("Sms tekrar gönderiminde hata oluştu!");
                    });
                    return false;
                }
            },
            {
                title: "Onay",
                attr: {
                    "id": "btnSmsOnay", "style": "float:right"
                },
                click: function () {
                    $("#lblHataMesaj").html("");
                    if (!$("#txtSmsSifre").val()) {
                        $("#lblHataMesaj").html("Sms kodu girilmelidir");
                        return false;
                    }
                    var url = apiBaseUrl + "/TeklifAl";
                    AxaLibrary.ExecuteApi(url, "POST", { "": $("#txtSmsSifre").val() } , function (msg) {
                        if (!msg.Success) {
                            if (msg.Data == "Sms") {
                                $("#lblHataMesaj").html(msg.Message);
                            } else {
                                clearInterval(smsTimer);
                                $("#SmsDialog").modal("hide");
                                toastr.error(msg.Message);
                            }
                            RefreshCaptcha();
                            return false;
                        } else {
                            clearInterval(smsTimer);
                            window.location.href = AppBaseUrl + "SagligimTamam/Prim_Detay";

                            try {
                                dataLayer.push({
                                    event: 'lead',
                                    lead_id: data,
                                    lead_product: 'Sağlığım Tamam',
                                    lead_category: 'Sağlık'
                                });
                            } catch (e) { }
                        }
                    });
                    return false;
                }

            }]
    });

}

function SulaleIndirimKayitOlustur() {
    if ($('#frmgenel').valid()) {

        var notify = false;
        if ($("#agree").is(":checked") && $("#elektronikiletionay").is(":checked")) {
            notify = true;
        }

        var parametreler = {
            "tcNo": $("#tc").val(),
            "cepTel": $("#cep").val().replace(/ /g, ''),
            "ePosta": $("#eposta").val(),
            "captcha": $("#secure").val(),
            "dogumTarihi": $("#dogumTarihi").val(),
            "musteriIzin": notify
        };

        var Url = sulaleIndirimliApiBaseUrl + "/SulaleIndirimliSigortaKayit";
        AxaLibrary.ExecuteApi(Url, "POST", parametreler, function (msg) {
            if (!msg.Success) {
                toastr.error(msg.Message);
            }
            else {
                SmsDogrulaKotasyon('SulaleIndirimliTSS');
            }
        }, function (xhr) {
            toastr.error("İşlem sırasında hata oluştu. Lütfen tekrar deneyin");
            RefreshCaptcha();
        });
    }
}