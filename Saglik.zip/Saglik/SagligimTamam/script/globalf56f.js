var fn = fn || {};
function numberKey(event) {
    var e = event;
    var charCode = e.which || e.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;
    return true;
};


function PrintElem(content)
{
    var mywindow = window.open('', 'PRINT', 'height=400,width=600');

    mywindow.document.write('<html><head><title>' + document.title  + '</title>');
    mywindow.document.write('</head><body >');
    mywindow.document.write(content);
    mywindow.document.write('</body></html>');

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
    mywindow.close();

    return true;
}

function validation(group) {
    function errorstatus(obj){
        obj.parents(".form-group").addClass("error");

    }

    var status = true;
    var mailfilter = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    $(".form-group").removeClass("error");
    $('.alert').addClass("hidden");


    $.each($(group + " .required"), function () {
        var obj = $(this);

        if ($.trim(obj.val()) === "" || $.trim(obj.val())===obj.data("val")) {
            errorstatus(obj);
            status = false;
        }

        if ($.trim(obj.val()) !== "" && obj.data("type") !== undefined && obj.data("type") === "mail" && !mailfilter.test(obj.val())) {
            obj.parents(".form-group").removeClass("success").addClass("error");
            status = false;
        }

        if (obj.data("type") !== undefined && obj.data("type") === "alphanumeric" && !fn.global.alphaNumeric(obj.val())) {
            obj.parents(".form-group").removeClass("success").addClass("error");
            status = false;
        }

        if (obj.val() !== "" && obj.data("min") !== undefined) {
            if (obj.val() !== "" && obj.val().length < parseInt(obj.data("min"))) {
                obj.parents(".form-group").removeClass("success").addClass("error");
                status = false;
            }
        }
    });
    return status;
}

function proposalSelection(obj) {
    var p = obj.parents(".proposal");
    $(".proposal .btn-select.selected").removeClass("selected");
    p.find(".btn-select").addClass("selected");

    $("#btn-teklif").prop("disabled", false);
}

$(document).ready(function() {

    $('#btn-sendForm').click(function(e){
        e.preventDefault();

        var status = validation('#formBasvur');
        // Başvuru formu
        if(status){
            $.ajax({
                type: "Post",
                url: "",
                data: $('#formBasvur').serialize(),
                dataType: "json",
                beforeSend: function () {

                },
                success: function (result) {
                    if(result.Success){
                        toastr.success('İşlem başarı ile tamamlandı.');

                    }else{
                        toastr.error('İşlem sırasında hata oluştu. Lütfen tekrar deneyin.');
                    }
                }
            });
        }else{
            toastr.error('Bilgilerinizi kontrol ediniz.');
        }

    });

    $('input, textarea').focus(function () {
        $(this).parents(".error").removeClass("error");
    });

    if($('.page-modal .page-content').length>0){
        $(".page-modal .page-content").mCustomScrollbar();
    }

    $(".go-up").click(function () {
        $("html, body").animate({scrollTop: 0}, 1e3)
    }), $(".faq-area .question").click(function () {
        var a = $(this).parents("li"), b = $(this);
        a.find(".answer").slideToggle(function () {
            b.toggleClass("active"), b.find(".fa-plus").toggleClass("fa-minus")
        })
    }), $(".close, .overlay").click(function () {
        $(".page-modal").addClass("hidden");
        $(".page-modal2").addClass("hidden");
        $(".step-pager li").removeClass("active");
        $(".step-pager li:eq(0)").addClass("active");
        $(".step").hide();
        $(".step.step1").show();
        $("body").css("overflow", "auto");
    }), $("body").on("click", ".mobile-buy-button", function (a) {
        a.preventDefault(), $(".hero-form").show()
    }), $("body").on("click", ".btn-step1", function (a) {
        a.preventDefault(), $(".step.step1").hide(), $(".step.step2").show(), $(".step-pager li").removeClass("active"), $(".step-pager li:eq(1)").addClass("active")
    }), $("body").on("click", ".btn-step2", function (a) {
        a.preventDefault(), $(".step.step2").hide(), $(".step.step3").show(), $(".step-pager li").removeClass("active"), $(".step-pager li:eq(2)").addClass("active")
    }), $("body").on("click", ".btn-open-privacymodal", function (a) {
        a.preventDefault(), $("body").css("overflow", "hidden"), $(".page-modal1").removeClass("hidden");
    }), $("body").on("click", ".btn-open-privacymodal2", function (a) {
        a.preventDefault(), $("body").css("overflow", "hidden"), $(".page-modal2").removeClass("hidden");
    });

    $("body").on("click", ".btn-open-healthdetail", function (a) {
        a.preventDefault(),
            $("body").css("overflow", "hidden"),
            $(".page-modal").removeClass("hidden");
    });

    if($(".iselect").length>0){
        $(".iselect").select2();
    }
    $('.btn-show-map').click(function(e){
        e.preventDefault();

        var temp = '<div class="page-modal mapmodal"> <div class="overlay"></div> <div class="page-container"> <span class="close">X</span> <div class="page-content">';
        temp += '<iframe src="'+$(this).data("url")+'" width="100%" height="550" frameborder="0" style="border:0" allowfullscreen></iframe>'
        temp += '</div></div></div>';
        $('body').append(temp);
        $('#mapDiv').append(temp);

    });


    $('body').on("click",".mapmodal .close, .mapmodal .overlay",function(){
        $('.mapmodal').remove();
    });

    $('.page-modal').on("click",".changefont",function(){
        var $t = $(this);
        var size =$t.data("fz")!== undefined?$t.data("fz"):12;
        if(size < 20){
            size+=2;
        }else{
            size=12;
        }
        $t.data("fz",size);
        var p = $t.parents(".page-content");

        p.find("p").css("font-size",size +"px");
    });


    $('.page-modal').on("click",".print",function(){
        var p = $(this).parents(".page-content");
        PrintElem(p.html());
    });

    $('.btn-accept-confirm').click(function(e){
        e.preventDefault();
        var status = $('#accept').prop("checked");
        if(status){
            location.href="step3.html";
        }
    });

    $('.btn-other-user-info').click(function(){
        var status = $('input[name=usertype]:checked').val();
        if(status === "true"){
            $('#other-user-info').slideDown();

        }else{
            $('#other-user-info').slideUp();
        }
    });
    //dogrudan ve acente secimi ile satin alma durumu
    $('.btn-satin-alma-secenek').click(function () {
        var status = $('input[name=satinAlmaSecenek]:checked').val();
        if (status === "acente") {
            $('#hemenOde').removeClass("hidden");

        } else {
            $('#hemenOde').addClass("hidden");
        }

    });



    //$('.accordion-item .agency-name').on('click', function () {
    //	var p = $(this).parent();
    //	if(p.hasClass("active")){
    //		p.find('.accordion-content').slideUp(function(){
    //			p.removeClass("active");
    //		});
    //	}else{
    //		p.addClass("active");
    //		p.find('.accordion-content').slideDown();
    //	}

    //});

    //$('.accordion-item .title').on('click', function () {
    //    debugger;
    //    var p = $(this).parent();
    //    if (p.hasClass("active")) {
    //        p.find('.accordion-content').slideUp(function () {
    //            p.removeClass("active");
    //        });
    //    } else {

    //        p.find('.accordion-content').slideDown(function () {
    //            p.addClass("active");
    //        });
    //    }

    //});

    $('.tabs a').click(function(e){
        e.preventDefault();
        var $t = $(this);
        if($t.hasClass("active")){
            return false;
        }
        $('.payment-summary #btn-buy').attr("href",$(this).data("link"));
        $('.tabs a').removeClass("active");
        $t.addClass("active");
        $('.tabcontainer .tabcontent').removeClass("active");
        $('.tabcontainer #'+$t.data("id")).addClass("active");


    });

    $('body').on("change", "#itaksit", function(){
        var val = $(this).val();
        if(val!==""){
            $('.taksit-secenekleri').removeClass("hidden");
        }else{
            $('.taksit-secenekleri').addClass("hidden");
        }
    });

    //$('.btn-accordion').click(function(){
    //	var $t = $(this);
    //	var p = $t.parents("li");

    //	if($t.hasClass("btn-cancel")){
    //		$t.removeClass("btn-cancel").text("Seç");
    //		p.removeClass("selected");
    //	}else{
    //		$t.parents('.item-list').find("li").removeClass("selected");
    //		$t.parents('.item-list').find("li .btn-accordion").removeClass("btn-cancel").text("Seç");

    //		$t.addClass("btn-cancel").text("Temizle");
    //		p.addClass("selected");
    //	}
    //});

    $('[data-toggle="tooltip"]').tooltip();


    $(window).scroll(function(){
        if ($(this).scrollTop() > 100) {
            $('.go-up').fadeIn();
        } else {
            $('.go-up').fadeOut();
        }
    });

    $('.go-up').click(function(){
        $('html, body').animate({scrollTop : 0},800);
        return false;
    });
    if($('.mask-cep').length>0){
        $('.mask-cep').inputmask("0(999) 999 99 99");
    }

    if ($('.mask-dogumtarih').length > 0) {
        $('.mask-dogumtarih').inputmask("dd/mm/yyyy", { "placeholder": "" });
    }

    $(".proposal .btn-select").on("click", function () {
        proposalSelection($(this));
    });

    ///* Kampanya Input Kontrol: Begin */
    //$(".input-check").click(function () {
    //    var p = $(this).parents(".input-group");
    //    if (p.hasClass("active")) {
    //        p.removeClass("active");
    //        p.find("input").prop("disabled", true).val('');

    //    } else {
    //        p.addClass("active");
    //        p.find("input").prop("disabled", false);
    //    }

    //});
    ///* Kampanya Input Kontrol: End */

    /* Tooltip: Begin */

    if (window.matchMedia("(min-width: 768px)").matches) {
        if ($(".icon-info").length > 0) {
            $(".icon-info").popover();
        }
    }
    $(".icon-info").click(function () {
        if (window.matchMedia("(max-width: 768px)").matches) {
            var t = $(this);
            t.popover('hide');
            $("#modalTooltip .modal-title").html(t.data("header"));
            $("#modalTooltip .modal-body").html(t.data("content"));
            if (t.data("video") !== undefined) {
                var v = '<video class="video" controls><source src="' + t.data("video") + '" type="video/mp4"></video>';
                $("#modalTooltip .modal-body").append(v);
            }
            $("#modalTooltip").modal("show");
        }
    });



    /* Tooltip: End */

});

